
To Run Server:

1.  Navigate to:
    cd c:...RecordStore\myworld\my_record_store

2.  Execute this to run server:
    py manage.py runserver

3.  Page should run on:
    http://localhost:8000/